# Standardized options and interfaces

**Signer interface:** `{getPublicKey(): Promise<hex64>, signEvent(unsigned): Promise<SignedNostrEvent>, close?()}`. Signing requires explicit approval in the user's selected signer. `Nostr.browserSigner`, `.bunkerSigner`, `.nostrConnectRequest`, and `Adapters.androidHandoff` adapt real hosts to this contract.

**Transport options:** `fetcher` is WHATWG `fetch`; `Socket` is the browser `WebSocket` constructor or a compatible injected constructor; `clock` returns Unix seconds; `signal` is an `AbortSignal`. Network results must be verified before status success. The tests inject deterministic mock transports solely for logic acceptance.

**Storage interface:** asynchronous `get(key)`, `set(key, value)`, `delete(key)`, `keys()`. Use IndexedDB for offline browser catalog/caches; `memoryStore` for tests or ephemeral state. Do not store remote-signing transport secrets in generic persisted state.

**Filename / URL constraints:** Files use canonical forward-slash site paths. No `..`, `.`, empty path components, query strings, fragments, backslashes, NUL, or encoded traversal. Relays are `wss://` and Blossom servers `https://`, validated separately. The default path policy does not automatically authorize private LAN SSRF to Blossom servers.

**Publication:** `(files, {signer,pubkey,server,relays,identifier,title,description,checkpoint})`. Each output stage is checkpointable. A prepared manifest is not a signed event; an upload response is not exact-byte verification; a relay `OK` is not successful readback; a gateway URL is not proof the gateway currently renders.

**Host compatibility:** Node >=20 supports direct Nostr crypto, ZIP and pure manifests. Browsers need `crypto.subtle`, `WebSocket`, `fetch`, `TextEncoder`; IndexedDB optional. Android app switching requires a host-specific callback. Shell/Codex NIP46 can use `bunkerSigner` after user-approved connection. Do not confuse signed publication and host deployment.
