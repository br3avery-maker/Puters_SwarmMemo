# Public API reference — Nsite Loopy SDK 1.1.0

`import {createNsiteSDK, Core, Nostr, Nsite, Blossom, Archive, Directory, Storage, Adapters, Moderation, Moji, Anchor} from '@chaoticka/nsite-loopy-sdk'`. `docs/API_INDEX.json` is the generated complete export list; `types/index.d.ts` is the TypeScript consumer contract. All storage and network functions are explicit: imports have no side effects.

## Facade

`createNsiteSDK(options?)` accepts `{relays:string[], server?:HTTPS_URL, signer?:Signer, storage?:StorageAdapter, Socket?:WebSocketConstructor, fetcher?:fetch, clock?:()=>seconds}`. It returns `{options, core, nostr, nsite, blossom, archive, directory, storage, adapters, moderation, moji, anchor, publish(files,overrides), query(filter,overrides)}`. `publish` reads the approved signer's identity if `pubkey` isn't supplied. A facade is optional: every namespace can be used independently.

## Core (11 exports)

- `bytes(input)` UTF-8/ArrayBuffer/Uint8Array to bytes; `encode(text)`, `hex(bytes)`, `unhex(hex)`; `toBase64Url(bytes)`; `sha256(bytes,{cryptoProvider?})` returns lowercase SHA-256 hex.
- `endpoint(value,type='relay')`: canonical plain `wss://` relay or `https://` Blossom URL, rejects credentials, fragments, queries and unsafe local targets for Blossom.
- `endpoints(urls,type,max)`: validate and deduplicate endpoint list.
- `nsitePath(path)`: canonical leading slash and dot/traversal protection; `slug(value)`: 1–13 lower-case canonical named-site identifier.
- `normalizeOptions(options)`: validates and returns standard runtime options.

## Nostr (32 exports)

- `generateSecretKey()`, `getPublicKey(secret)`, `finalizeEvent(unsigned,secret)`: crypto/test primitives. Do not serialize test private keys into public artifacts; normal apps should use external signers.
- `verifyEvent(event)`: BIP-340 signature verification on clean canonical event fields, guarding against vendor verification memoization. `assertSignedEvent(event)` throws on invalid signatures.
- `eventTemplate({kind,created_at,content,tags})`, `checkedSign(signer,template,expectedPubkey)`: validate approved event bytes and author identity before using a signed result.
- `browserSigner(window.nostr)`: NIP-07 adapter, errors when absent. `bunkerSigner(uri,options)`: NIP-46 signer object requiring `.connect()` then approval; `.close()` stops session.
- `nostrConnectRequest({relays,name,perms,secret?,clientSecret?})`: generate client-initiated `nostrconnect://` copy code and `start(signal)` listener; start listening before app switch; do not regenerate pending attempts casually.
- `androidIntent({type,requestId,event?,currentPubkey?,callbackUrl?})`: creates Android NIP-55 request URI; **launch only**, not login. `verifyAndroidResult(...)` validates correlation, author, content and signature after Android host returns. `connectIdentity(signer)` confirms identity via the signer.
- `relayList(kind10002)`: signed NIP-65 read/write list; `planRelays({authorList,recipientLists,defaults,max})`: bounded role-aware relay selection. `discoverRelays(pubkey,{bootstrap,query,defaults,max})`: retrieve latest signed kind10002 and diagnostics. `relayInfo(url,{fetcher})`: NIP-11 metadata over HTTPS. `blossomServers(kind10063)` / `discoverBlossom(pubkey,{bootstrap,query})`: signed BUD-03 discovery.
- `queryRelay(relay,filter,{Socket,timeoutMs,signal,verify,maxEvents})`: finite REQ/EOSE; returns verified deduplicated signed events, errors instead of masquerading network failure as empty content. `publishRelay(relay,event,{Socket,...})`: waits for actual OK, then signed exact-ID readback; `publishMany(event,relays,{writer?})`: returns verified/failure receipts without hiding partial failures.
- `textNote(content,{replyTo?})`: kind1 plain note, with `e`/`p` reply tags; `reaction(target,emoji='+')`: kind7 reaction. `publishTemplate(template,{signer,pubkey,relays,publisher?})`: checked signed publication, requiring readback. `fetchFeed({authors,kinds,relays,query?,limit?})`: verified, deduped, time-sorted events plus per-relay failures.
- `parseProfile(signedKind0)` / `fetchProfiles({pubkeys,relays,query?})`: extract bounded metadata from signed profiles.
- `relayAuthTemplate({challenge,relay})`: NIP-42 challenge-bound template; `httpAuthHeader({url,method,signer,pubkey})`: signed NIP-98 HTTP auth. `encryptionAdapter(nip44Signer)`: delegates to trusted signer; **does not invent homemade NIP-44 encryption**.

## Nsite (10 exports)

- `NSITE_ROOT_KIND=15128`, `NSITE_NAMED_KIND=35128`, `nsiteAddress(pubkey,{identifier?,gateway?})`: root/named nsite URLs.
- `prepareManifestFiles(fileMap,{maxFiles?,maxBytes?})`: normalizes each path, hashes exact bytes and computes deterministic aggregate of sorted `<hash> <path>\n` records. Returns `{entries,aggregate,totalBytes}`.
- `manifestTemplate(prepared,{identifier?,server?,title?,description?,created_at?})`: unsigned kind15128/35128 manifest. `parseManifest(signedEvent,{verify?,now?})`: signature check, path bounds, aggregate check and site URL.
- `normalizeFileMap(fileMap)`, `compareFiles(before,after)`, `mediaType(path)`: normalized file paths, changed hashes, MIME types.
- `publishNsite(fileMap,{signer,pubkey,server,relays,identifier,title,description,uploader?,publisher?,checkpoint?,signal?})`: prepare → upload each exact asset → verify → sign manifest → publish → independent relay readback → stage receipt. Stops on any failed gate. Returns `{job,event,manifest,receipts}`.

## Blossom (4 exports)

- `blossomUploadAuth({hash,server,now?,expiresIn?})`: unsigned kind24242 upload auth (caller signs).
- `blossomAuthHeader(signedEvent)`: Nostr event base64url authorization header.
- `uploadVerified(bytes,{server,signer,pubkey,path,fetcher?,signal?})`: cryptographic sign → PUT `/upload` → descriptor check → GET hash readback and SHA-256 comparison. Returns `{hash,size,server,url,verified:true}` only after exact byte match.
- `fetchVerified(hash,{servers,fetcher?,signal?})`: tries verified HTTPS Blossom URLs in order and returns first exact-hash copy. Throws if none match.

## Archive (9 exports)

- `writeZip(fileMap,{maxFiles,maxBytes})`: deterministic stored ZIP with CRC32 and central directory, no external compressor. `readZip(bytes,{maxFiles,maxOutputBytes,maxRatio,inflate?})`: validates central directory, names, CRC, sizes, path traversal, symlinks and expansion. Reads stored/DEFLATE; Node uses built-in `zlib` for DEFLATE, browsers may inject `inflate`.
- `crc32(bytes)`: ZIP checksum (not a cryptographic hash).
- `contentStore(storage?)`: content-addressed `put/get/verify/saveManifest/loadManifest/keys`, using hash identity and shared storage interface.
- `diffVersions(previous,next)`, `materializeVersion(manifest,store)`, `groupVersions(versions)`: compare historical manifest paths, rebuild version from CAS and group by publisher/root/named identifier.
- `buildArchiveCatalog(versions,{pages?,jobs?,settings?})` / `searchArchive(catalog,{query,sort,offset,limit,publisher,includeHidden})`: searchable version lineage; hide local entries without erasing raw input.

## Directory (31 exports)

Source-derived `Nsite Directory Editor/app/model.js` plus `htmlMetadata`:

- `emptyState`, `validateCatalog`, `validateWorkspace`, `validateRules`, `upgrade`, `VERSION`, `defaultRules`: versioned workspace and schema checks.
- `effective`, `matches`, `reasons`, `select`, `directoryRows`, `SORTS`, `safeURL`, `safeImage`, `htmlMetadata`: effective metadata, filter rules, search/sort, safe links/images, static metadata.
- `patch`, `bulkGroup`, `stackSites`, `unstack`, `membership`, `groupState`, `toggleState`, `publisherCounts`, `publisherKey`, `similarityKey`, `setQueue`, `moveQueue`, `ageSeconds`: revisioned edits, clone stacks independent of collections, search/sort, queue navigation.
- `exportCatalog`, `publicCatalog`: reversible JSON export and public-only catalog with hidden entries filtered.

## Storage (2 exports)

`memoryStore(seed?)`: async clone-on-read `get/set/delete/keys` in memory. `indexedDbStore({name,store,indexedDBProvider?})`: same contract via browser IndexedDB. Secrets must be managed by the signer; don't store `nsec` or bunker connection tokens in the generic library.

## Adapters (2 exports)

`browserEnvironment({signer?,storage?,Socket?,fetcher?})`: browser host capability detection. `androidHandoff({launch,onReturn})`: host-provided NIP-55 request and correlated result. **Requires a native Android host callback, not just a URL click.**

## Failure states

- `Error` indicates unverified publication, network timeout, corrupt archive, signature mismatch, missing signer, incompatible host, or invalid bytes; callers should not substitute a success message.
- `fetchFeed`/`discoverRelays` return diagnostics when at least one relay failed. A signed event fetched from one relay does not prove availability on others.
- Pure operations (`writeZip`, `nsitePath`, `manifestTemplate`) have no network or side effects.

Machine-readable export inventory: `docs/API_INDEX.json`; typed API: `types/index.d.ts`; tested call graph: `docs/DEEPINK_CONSUMER.md`.

## Moderation

- `campaignMatch(description)` preserves the confirmed three-signal spam campaign: role opener, resource promise after opener, real external link (not `index.html` or `Node.js`).
- `inspectNsiteSpam(site)` distinguishes `confirmed`, `review` and `clear` with inspectable reasons; `clusterNsiteSpam(sites)` detects repeated description templates from distinct authors without turning a guess into an irreversible block.
- `filterNsites(sites,{bannedPubkeys,hideConfirmed,hideSuspected=false,ownPubkey})` excludes confirmed spam from *visible* results, protects local/pinned items, and returns all hidden rows plus decisions. Original records stay untouched.
- `parseCuratorBlocklist(json)` and `mergeBlocklists` import/export user-curated publisher and SHA-256 media hashes. Known NSFW publisher/hashes/URL lists are *data*, not media downloads. No content is fetched or rendered.
- `isEmojiAllowed(candidate,policy)` supports open-with-banlist or verified-safe-publishers-only, without filename/shortcode keyword censorship. `normalizePubkey`, `decodeNip19`, `normalizeEmojiHash` validate identifiers.
- `parseNip51MuteList(signedEvent)` verifies a kind-10000 event signature before extracting muted authors. `muteListTemplate(pubkeys)` creates an unsigned template only; no automatic publish.

## Moji

- `extractEmojiHash(url)` extracts an embedded Blossom SHA-256 when present, or computes a deterministic canonical URL fingerprint otherwise; a URL fingerprint is **not** a verified media content hash.
- `buildStableEmojiKey(url,source)` uses `nip30:<hash>` or `reserve:<hash>`, not a mutable shortcode. `deriveEmojiStatsFromHash` and `deriveEmojiStats` port MojiSurvivor's deterministic hash-driven stats and rarity tiers.
- `parseNip30Event(signedEvent,{policy})` imports signed kind 30030 / 10030 emoji tags while applying publisher/media bans. `collectNip30Emojis(events)` deduplicates by media identity, returns exclusions and unresolved `a` references. It never claims to have fetched linked packs automatically.

## Anchor

- `sanitizePublicSession`, `buildPublicAccountBackup`, `restorePublicAccountBackup`: public-only account configuration exports. No `nsec`, bunker URI, signer credential, or private auth state. Restore is **always read-only until reapproved** and checks saved signed publication events.
- `summarizePublicationReceipts` separates accepted `OK` from **independently retrieved**. `extractEventAssets` parses the `imeta` URL tags from verified events without fetching or rendering media.
- `kindSpec`, `classifyEventStorage` are derived from Anchor's NIP-kind registry and NIP-01 storage rules.
- `assessRelayOutbox`, `planVerifiedOutbox` accept probe evidence, do not assume unknown relays are healthy, and recommend writes only when an actual write probe is recorded.

## Archive (Gear profile additions)

- `GEAR_PROFILE`, `gearChunks(data)` reproduce Pretend Internet's exact Gear CDC profile (`gear-v1-16k-64k-256k`); chunking is internal and does not replace Blossom whole-file SHA-256 or NIP-5A aggregates.
- `chunkManifest(bytes)` creates a hashed reusable chunk manifest; `restoreChunkManifest(manifest,read)` verifies every chunk and final whole-file bytes.
- **No Hashtree codec bundled.** This does not claim byte-for-byte HTS-01 node interoperability; use the canonical upstream `@hashtree/core` encoder separately.
