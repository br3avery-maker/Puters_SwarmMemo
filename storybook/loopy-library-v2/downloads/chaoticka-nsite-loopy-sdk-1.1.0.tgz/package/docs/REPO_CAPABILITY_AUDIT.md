# Repository-wide Loopy recovery audit — 2026-11-22

The GitHub connector listed 46 accessible repositories. Code search was targeted at Nostr, nsite, relay, Blossom, signer, spam, emoji, game, archive, wallet, content, account and app-tool mechanisms. **46 repositories listed does not mean every source file in every repository was audited.** See `provenance/repo-capabilities.json` for source paths, disposition, and specific remaining gaps.

## Adopted in this SDK 1.1.0

- MojiSurvivor: curated publisher/emoji-media hash blocklists, signed NIP-51 muted authors, safe-list policies, NIP-30 emoji import and stable hash identities, deterministic emoji combat traits.
- Pretend Internet + piShell: confirmed three-signal campaign detection. HowAmIADeveloper Studio: cross-account template clustering, reported as reversible review evidence rather than blanket auto-ban.
- Nostr Anchor: public-only account backup and signed-publication restore, independent relay receipt states, NIP-kind classification, evidence-based relay outbox planning.
- Pretend Internet archive: identical Gear-v1 CDC chunk boundaries and hash-verified restoration of chunk sets. Native HTS-01 codec remains a separate optional integration.

## Existing capabilities reused, not forked

NIP-55 signer callback, NIP-46 bunker, NIP-07, NIP-65 relay discovery, NIP-11 probing, BUD-03/11 and Blossom verification, NIP-5A publishing, NIP-42/98, kind 1/7 posts and reactions, indexedDB, ZIP/CAS, directory curation.

## Still separate or awaiting a consumer test

A full Android ActivityResult/ContentResolver signer app integration (Ngit Studio/HowAmI); Moji's arena/game states, trading card PNG, blinkie rendering, leaderboards, NIP-30 reference follow-up network client, external moderation-report aggregation; live relay reputation sampling; portable `@hashtree/core` HTS-01 codec; cross-device archive worker and sandboxed previews; ngit/git publishing and remote sync; advanced image/video/audio players, feed rendering, NIP-19 routing, and multi-account UI controllers.

These are not silently called implemented. Unintegrated candidates remain mapped to their original repo paths for their respective consumers and skill adapters.

## Acceptance

Run `npm test`, `npm run test:types`, `python3 validation/verify_package.py`, and `python3 validation/verify_repo_audit.py` from this SDK directory. Browser/mobile/signer relays and publication require separate test receipts.
