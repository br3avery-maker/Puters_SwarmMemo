# Exact source-code collection and provenance

The companion `Nsite-Loopy-Full-Source-Collection-2026-11-22.zip` is generated from **38 accessible source ZIP/HTML inputs** in ChatGPT Library. It preserves **2,546 code/document occurrences** as **1,367 unique SHA-256-addressed files**, with paths and source-archive SHA-256 references for reconstruction. Another 529 entries were non-code/binary or exceeded bounded source extraction checks and remain in the originals, not represented as adopted reusable code.

Collection SHA-256: `908fc87b5f9fef26bfd830db8532cab75e41f4b896707b44952fe534cbcb8a78`. Size: 7371505 bytes.

The companion ZIP includes `MANIFEST.json`, an `objects/sha256/` store and `README.md`. Restore using `python scripts/source_collection.py restore --bundle ... --out ...`. Original source archives remain in the Library and retain full ZIP metadata/binary assets. The SDK is the independently testable standardized API layer; the companion source collection is not auto-loaded or publicly licensed.

Categories inventoried include nsite manifests, web publishing, signer adapters, relay discovery/probing, Blossom uploads, directory models, archives/ZIPs, offline storage, editor components, profile/feed modules, Android host code, existing agent skills and source tests. Distinct app components are not mislabelled importable SDK modules without consumer verification.

Current gaps: unmountable Project-source Library items cannot be represented byte-identically; actual device/relay host tests for this consolidated SDK have not been performed. See `docs/DEEPINK_CONSUMER.md` for the next host acceptance gate.
