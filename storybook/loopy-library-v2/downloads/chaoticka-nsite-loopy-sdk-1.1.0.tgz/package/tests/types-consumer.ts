import {createNsiteSDK,Nsite,Nostr,Archive,Storage,Directory,Blossom,Core,type FileMap,type Signer} from '../types/index.js';
const files:FileMap={'index.html':'hello'};
const sdk=createNsiteSDK({relays:['wss://r.example'],server:'https://blossom.example'});
const template:ReturnType<typeof Nostr.textNote> = Nostr.textNote('hello');
const manifestPromise=Nsite.prepareManifestFiles(files);
const hashPromise=Core.sha256('value');
const zip:Uint8Array=Archive.writeZip(files);
const store=Storage.memoryStore();
const state=Directory.emptyState();
const _publish=sdk.publish(files);
void [template,manifestPromise,hashPromise,zip,store,state,_publish,Blossom];

// Repo-wide Loopy 1.1.0: type contracts exercised by external SDK consumers.
import {Moderation, Moji, Anchor} from '../src/index.js';
const inspected: string = Moderation.inspectNsiteSpam({title:'Safe',description:'Archive'}).status;
const slug: string | null = Moderation.normalizePubkey('a'.repeat(64));
const stats: number = Moji.deriveEmojiStatsFromHash('a'.repeat(64)).hp;
const anchorStorage: 'regular'|'replaceable'|'ephemeral'|'addressable' = Anchor.classifyEventStorage(10000);
const gearBlocks: Uint8Array[] = Archive.gearChunks(new Uint8Array([1,2,3]));
void [inspected, slug, stats, anchorStorage, gearBlocks];
