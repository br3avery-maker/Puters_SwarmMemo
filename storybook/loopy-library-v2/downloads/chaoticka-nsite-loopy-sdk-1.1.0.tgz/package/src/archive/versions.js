import {nsitePath} from '../core/urls.js';
/** Deterministic reconstruction of a historical version from stored paths and CAS objects. */
export async function materializeVersion(manifest,store){
  const files=Object.create(null);
  for(const entry of manifest.files){const path=nsitePath(entry.path).slice(1);const value=await store.get(entry.hash);if(!value)throw new Error('Missing content for '+path);files[path]=value;}
  return files;
}
export function diffVersions(previous,next){
  const a=new Map(previous.files.map(f=>[nsitePath(f.path),f.hash])),b=new Map(next.files.map(f=>[nsitePath(f.path),f.hash]));const changes=[];
  for(const path of new Set([...a.keys(),...b.keys()]))if(a.get(path)!==b.get(path))changes.push({path,kind:!a.has(path)?'added':!b.has(path)?'deleted':'changed',before:a.get(path)||null,after:b.get(path)||null});
  return changes.sort((x,y)=>x.path.localeCompare(y.path));
}
export function groupVersions(versions){const out=new Map();for(const v of versions){const key=v.kind===35128?`${v.pubkey}:35128:${v.identifier}`:`${v.pubkey}:15128`;const group=out.get(key)||[];group.push(v);out.set(key,group)}for(const a of out.values())a.sort((x,y)=>(y.created_at||0)-(x.created_at||0));return out}
