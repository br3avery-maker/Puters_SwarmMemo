import {normalizePubkey,normalizeEmojiHash,normalizePubkeyList,normalizeHashList} from './identity.js';
import {assertSignedEvent,eventTemplate} from '../nostr/events.js';
// Copied as explicit user-curated *data* from MojiSurvivor's moji-curator-blocklist/v1. No media fetched.
export const MOJI_CURATOR_BLOCKLIST_VERSION='moji-curator-blocklist/v1';
export const BUILT_IN_NSFW_BAN_PUBKEYS=Object.freeze([
'1a21da9d5ae3dffdac19adf5e400394401f67f8da4113a1b7bdece35b0d99fe2','415778be61cfd789cd58eb06c902706b49dc7da16b0a22125670dff33d81dc42','f4b55ea7491fb70849afa6f673fc58846b61ce7efb1d8051bbae35d1a13a48ab','983d5dae1d2280926cf90c037394dbda4348503f4cc342464df7fde98cabecdf','626b275b16dec6db7a27e807c2db690e71b4d42d482f1817ab370601eeabb735','0b7943cce4a9c7fee87a7921b6201d4f847defc2064d6ba6ad3e3f6cdc43c1b3','0a717f27d9ef6f45dafe49f14a49fa4bac8c51b7efc85ff1f318779d8c43707b','4b56bbf41c92e586e88927acb78836eb49f2b184081ef852625cf78be7d56bd6','025cf9571bc0c7172802bcb37c9de29fcc852f59a4f7c84231ef8eb6fcae30dc']);
export const BUILT_IN_NSFW_MEDIA_URLS=Object.freeze([
'https://cdn.discordapp.com/emojis/526833864975319060.gif','https://cdn.discordapp.com/emojis/1006279765629620244.gif','https://blossom.ditto.pub/74bcdbdfafbf4656cf10f91c55b080e736ddb0813ff664ae032c5b19264346eb.gif','https://cdn.discordapp.com/emojis/1011386162633527388.png']);
export const BUILT_IN_NSFW_BLOB_HASHES=Object.freeze(["13693e97caaa56eedfed9f02ef6fcd547263a16b378cccf72e0e6001ceca9528", "b0fd902f9792d641a7c22cbd60ff05e620ba836e656d9ed9365f6192765b7b3e", "74bcdbdfafbf4656cf10f91c55b080e736ddb0813ff664ae032c5b19264346eb", "05f74b8e6f0596128715ebf74b2058d13d330922bcaa2f4e092b259d5e42b002"]);
export function parseCuratorBlocklist(raw){let v;if(typeof raw!=='string'||!raw.trim())throw Error('Blocklist JSON required');try{v=JSON.parse(raw)}catch{throw Error('Invalid blocklist JSON')}if(!v||typeof v!=='object')throw Error('Blocklist must be JSON array or object');
 const pubs=[],hashes=[],urls=[];
 function entry(obj){if(typeof obj==='string'){const p=normalizePubkey(obj),h=normalizeEmojiHash(obj);if(p)pubs.push(p);else if(h)hashes.push(h);else if(/^https:\/\//i.test(obj))urls.push(obj);return}if(!obj||typeof obj!=='object')return;for(const k of ['author','pubkey','sourceAddress'])if(typeof obj[k]==='string'){const p=normalizePubkey(k==='sourceAddress'?obj[k].split(':')[1]:obj[k]);if(p)pubs.push(p)}if(typeof obj.hash==='string')hashes.push(obj.hash);if(typeof obj.url==='string'&&/^https:\/\//i.test(obj.url))urls.push(obj.url)}
 if(Array.isArray(v))v.slice(0,10000).forEach(entry);else{
  for(const k of ['blockedPublishers','nsfwBanPubkeys','pubkeys','safePubkeys'])if(Array.isArray(v[k]))v[k].slice(0,10000).forEach(entry);
  for(const k of ['nsfwBanEmojiHashes','emojiHashes','hashes'])if(Array.isArray(v[k]))hashes.push(...v[k].slice(0,10000));
  for(const k of ['blocked','media'])if(Array.isArray(v[k]))v[k].slice(0,10000).forEach(entry);
 }
 return {schema:MOJI_CURATOR_BLOCKLIST_VERSION,pubkeys:normalizePubkeyList(pubs),emojiHashes:normalizeHashList(hashes),mediaUrls:[...new Set(urls)].slice(0,10000)};
}
/** NIP-51: only verified signer output is accepted. Hashed words and private encrypted content are outside this parser. */
export function parseNip51MuteList(event){if(event?.kind!==10000)throw Error('Expected NIP-51 kind 10000');assertSignedEvent(event);return {pubkey:event.pubkey,pubkeys:normalizePubkeyList(event.tags.filter(t=>t[0]==='p').map(t=>t[1])),eventId:event.id,createdAt:event.created_at};}
export function muteListTemplate(pubkeys,{created_at=Math.floor(Date.now()/1000)}={}){const tags=normalizePubkeyList(pubkeys).map(p=>['p',p]);return eventTemplate({kind:10000,content:'',tags,created_at})}
/** No user decisions are silently replaced by fetched lists. */
export function mergeBlocklists(...lists){const p=[],h=[],u=[];for(const l of lists){p.push(...(l?.pubkeys||[]));h.push(...(l?.emojiHashes||[]));u.push(...(l?.mediaUrls||[]))}return {pubkeys:normalizePubkeyList(p),emojiHashes:normalizeHashList(h),mediaUrls:[...new Set(u)]}}
/** Default = block exact known publishers or hashes, never keywords/shortcodes. */
export function isEmojiAllowed(candidate,policy={}){
 if(candidate?.source==='reserve')return true;
 const author=normalizePubkey(candidate?.packAuthor),hash=normalizeEmojiHash(candidate?.hash);
 if(candidate?.emojiKey&&new Set(policy.blockedEmojiKeys||[]).has(candidate.emojiKey))return false;
 if(author&&new Set(normalizePubkeyList(policy.bannedPubkeys===undefined?BUILT_IN_NSFW_BAN_PUBKEYS:[...policy.bannedPubkeys])).has(author))return false;
 if(hash&&new Set(normalizeHashList(policy.bannedEmojiHashes===undefined?BUILT_IN_NSFW_BLOB_HASHES:[...policy.bannedEmojiHashes])).has(hash))return false;
 if(policy.filterMode==='safe_list_only')return !!author&&(new Set(normalizePubkeyList(policy.safePubkeys?[...policy.safePubkeys]:[])).has(author)||Boolean(policy.isSignedIn&&author===normalizePubkey(policy.activeUserPubkey)));
 return true;
}
