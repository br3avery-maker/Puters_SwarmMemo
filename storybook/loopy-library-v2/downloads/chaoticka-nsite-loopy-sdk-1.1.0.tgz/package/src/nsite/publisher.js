import {prepareManifestFiles,manifestTemplate,parseManifest} from './manifest.js';
import {checkedSign} from '../nostr/events.js';
import {uploadVerified} from '../blossom/client.js';
import {publishMany} from '../nostr/relay-transport.js';
/** Fully verified NIP-5A pipeline. No user credentials: signer injected and explicit. */
export async function publishNsite(files,{signer,pubkey,server,relays,identifier='',title='',description='',uploader=uploadVerified,publisher=publishMany,checkpoint=async()=>{},signal}={}){
  if(!signer||!/^[0-9a-f]{64}$/.test(pubkey||''))throw new TypeError('Approved signer and author pubkey required');
  if(!server||!Array.isArray(relays)||!relays.length)throw new TypeError('Blossom server and relays required');
  const prepared=await prepareManifestFiles(files);
  const job={schema:'nsite-job/1',identifier,aggregate:prepared.aggregate,files:[],relays:[],stage:'prepared'};
  await checkpoint(structuredClone(job));
  for(const entry of prepared.entries){if(signal?.aborted)throw new Error('Cancelled');const result=await uploader(entry.bytes,{server,signer,pubkey,path:entry.path,signal});if(!result?.verified||result.hash!==entry.hash)throw new Error('Unverified Blossom upload '+entry.path);job.files.push({path:entry.path,hash:entry.hash,size:entry.size});job.stage='uploading';await checkpoint(structuredClone(job));}
  const unsigned=manifestTemplate(prepared,{identifier,server,title,description});
  const event=await checkedSign(signer,unsigned,pubkey);
  job.stage='signed';job.eventId=event.id;await checkpoint(structuredClone(job));
  const receipts=await publisher(event,relays,{signal});
  job.relays=(receipts.verified||[]).filter(r=>r?.readback===true&&r?.relay&&r?.accepted!==false);
  if(!job.relays.length)throw new Error('No signed nsite manifest was independently read back');
  const parsed=await parseManifest(event);job.url=parsed.url;job.stage='relay-verified';await checkpoint(structuredClone(job));
  return {job,event,manifest:parsed,receipts};
}
