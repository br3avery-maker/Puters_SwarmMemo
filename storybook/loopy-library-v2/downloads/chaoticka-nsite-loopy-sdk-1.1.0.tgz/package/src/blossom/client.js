import {endpoint} from '../core/urls.js';
import {bytes,sha256,toBase64Url,encode} from '../core/bytes.js';
import {eventTemplate,checkedSign} from '../nostr/events.js';
import {mediaType} from '../nsite/files.js';
export function blossomAuthHeader(signedEvent){return 'Nostr '+toBase64Url(encode(JSON.stringify(signedEvent)))}
export function blossomUploadAuth({hash,server,expiresIn=600,now=Math.floor(Date.now()/1000)}={}){
  if(!/^[0-9a-f]{64}$/.test(hash))throw new TypeError('SHA-256 hash required');
  return eventTemplate({kind:24242,created_at:now,tags:[['t','upload'],['expiration',String(now+expiresIn)],['server',new URL(endpoint(server,'blossom')).hostname],['x',hash]],content:'Upload nsite asset '+hash.slice(0,16)});
}
/** Real BUD-11 upload + descriptor + exact-byte readback; signer stays external. */
export async function uploadVerified(data,{server,signer,pubkey,path='file',fetcher=globalThis.fetch,signal,clock}={}){
  if(!fetcher)throw new Error('fetch transport required');
  const body=bytes(data),hash=await sha256(body),base=endpoint(server,'blossom');
  const unsigned=blossomUploadAuth({hash,server:base,now:clock?.()??Math.floor(Date.now()/1000)});
  const event=await checkedSign(signer,unsigned,pubkey);
  const response=await fetcher(base+'/upload',{method:'PUT',headers:{Authorization:blossomAuthHeader(event),'Content-Type':mediaType(path),'X-SHA-256':hash},body,signal});
  if(!response.ok)throw new Error('Blossom upload HTTP '+response.status);
  const descriptor=await response.json();
  if(descriptor.sha256!==hash||descriptor.size!==body.length)throw new Error('Blossom descriptor mismatch');
  const remote=await fetcher(base+'/'+hash,{cache:'no-store',signal});
  if(!remote.ok||await sha256(new Uint8Array(await remote.arrayBuffer()))!==hash)throw new Error('Blossom download integrity mismatch');
  return {hash,size:body.length,server:base,verified:true,url:base+'/'+hash};
}
export async function fetchVerified(hash,{servers=[],fetcher=globalThis.fetch,signal}={}){
  if(!/^[a-f0-9]{64}$/.test(hash))throw new TypeError('Hash required');
  const failures=[];
  for(const input of servers){const server=endpoint(input,'blossom');try{const response=await fetcher(server+'/'+hash,{signal});if(!response.ok)throw new Error('HTTP '+response.status);const data=new Uint8Array(await response.arrayBuffer());if(await sha256(data)!==hash)throw new Error('Content hash mismatch');return {server,data,hash}}catch(e){failures.push({server,error:e.message})}}
  throw new AggregateError(failures.map(e=>new Error(`${e.server}: ${e.error}`)),'No Blossom copy passed SHA-256');
}
